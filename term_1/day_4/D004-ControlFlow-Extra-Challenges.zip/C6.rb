### Challenge 6 - Medium
### Profile Builder
# Prompt the user for their name & age.
# Using ranges, determine what stage of life they're in (eg. baby, kid, teen, young adult, adult, senior)
# Get the current system time
#
# Display this data back to the user:
# - user name
# - user life stage
# - last login time
#
# Make the Ruby program wait for 5 seconds, and then clear the screen.
# 
